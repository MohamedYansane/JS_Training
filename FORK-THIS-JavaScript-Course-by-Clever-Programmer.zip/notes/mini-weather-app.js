let weather = prompt('How is the weather?')

if (weather == 'rainy') {
  console.log('Grab your umbrella ☔')
} else {
  console.log('Wear your sunglasses 😎')
}