name = 'Peter Pan'
console.log(name)

sentence = 'how are you doing today, nice to see you, hope you have a great day!'