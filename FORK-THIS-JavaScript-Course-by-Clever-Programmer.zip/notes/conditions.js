// How would you determine what to wear based on the weather?

let weather = prompt("How is the weather?")

if(weather == 'rainy') {
  console.log('Grab your umbrella ☔')
} else {
  console.log('Wear your sunglasses 😎')
}

// What do you change in the code so that your can wear sunglasses?


// BONUS: What's the difference between '=' and '=='?