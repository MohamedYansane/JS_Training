console.log('hello world')
console.log('Rafeh Qazi')