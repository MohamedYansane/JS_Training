// Test you code by forking this repl: 
// 👉 COMMING SOON!


// Write a function that takes in an array and sort the numbers inside from least to greatest

function sortArray (array) {
  
}

// BONUS sort the array without using .sort()

